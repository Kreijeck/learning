# Beispielprogramm für das Buch "Python Challenge"
#
# Copyright 2020 by Michael Inden


text = "this is a very special string"

print(text.capitalize())
print(text.title())
